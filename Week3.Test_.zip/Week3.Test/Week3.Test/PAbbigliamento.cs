﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3.Test
{
    class PAbbigliamento : Prodotto
    {

        public string Taglia { get; set; }
        public string Brand { get; set; }
        public PAbbigliamento(string c, string d, double p, int s, string t, string b) : base(c,d, p, s)
        {
            Taglia = t;
            Brand = b;
        }

    }
}
