﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3.Test
{
    class PAlimentare : Prodotto
    {
        public DateTime DataScadenza { get; set; }
        public PAlimentare(string c, string d, double p, int s, DateTime ds) : base(c, d, p, s)
        {
            DataScadenza = ds;
        }
    }
}
