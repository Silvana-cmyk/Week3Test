﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3.Test
{
    class PElettronica : Prodotto
    {
        public string Produttore { get; set; }
        public PElettronica(string c, string d, double p, int s, string pr) : base(c, d, p, s)
        {
            Produttore = pr;
        }
    }
}
