﻿using System;
using System.Collections.Generic;

namespace Week3.Test
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Utente> listaUtenti = new List<Utente>();
            Utente user1 = new Utente("PrimoUtente", "Pass1234", "Mario", "Rossi");
            Utente user2 = new Utente("SecondoUtente", "Pass5678", "Lucia", "Bianchi");
            listaUtenti.Add(user1);
            listaUtenti.Add(user2);

            List<Prodotto> listaProdotti = new List<Prodotto>();
            Prodotto p1 = new PAbbigliamento("vg1223", "Vestito blu Guess", 118, 0, "38", "Guess");
            //Prodotto p2 = new PAlimentare("usr456", "USB Sony rosa", 43, 20, new DateTime.Today);
            Prodotto p3 = new PElettronica("usb123", "USB Sony blu", 43, 0, "Sony");
            Prodotto p4 = new PElettronica("usr456", "USB Sony rosa", 43, 20, "Sony");
            listaProdotti.Add(p1);
            //listaProdotti.Add(p2);
            listaProdotti.Add(p3);
            listaProdotti.Add(p4);

            Console.WriteLine("---Inserisci Username---");
            string username = Console.ReadLine();
            Console.WriteLine("---Inserisci Password---");
            string password = Console.ReadLine();
            int flag = 0;
            Utente user = null;
            foreach (Utente item in listaUtenti)
            {
                if (item.Username == username || item.Password == password)
                {
                    flag = 1;
                    user = item;
                }
            }
            if (flag==0)
            {
                Console.WriteLine("error");
            }
            else
            {
                int i = Menu(ref listaProdotti, ref user);
                while (i != 0)
                {
                    AnalizzaScelta(i, ref listaProdotti, ref user);
                    i = Menu(ref listaProdotti, ref user);
                }
            }

        }

        private static int Menu(ref List<Prodotto> lista, ref Utente utente)
        {

            Console.WriteLine("1. Aggiungi prodotto nel carrello");
            Console.WriteLine("2. Elimina prodotto dal carrello");
            Console.WriteLine("3. Modifica la quantità di un prodotto");
            Console.WriteLine("4. Visualizza carrello");
            Console.WriteLine("0. Esci");

            int scelta;
            bool succ = Int32.TryParse(Console.ReadLine(), out scelta);

            if (succ != true || (scelta < 0 || scelta > 4))
            {
                Console.WriteLine();
                Console.WriteLine("Inserisci un valore corretto.");
                Console.WriteLine();
                scelta = 99;
                // break;
            }
            return scelta;
        }

        private static void AnalizzaScelta(int scelta, ref List<Prodotto> lista, ref Utente utente)
        {
            switch (scelta)
            {
                case 1:
                    Aggiungi(lista, utente);
                    break;
                case 2:
                    Rimuovi(lista, utente);
                    break;
                case 3:
                    ModificaCarrello(lista, utente);
                    break;
                case 4:
                    VisualizzaCarrello(utente);
                    break;
                default:
                    scelta = 0;
                    break;
            }
        }

        private static void Aggiungi(List<Prodotto> lista, Utente utente)
        {
            int i = 0;
            Console.WriteLine("Quale prodotto voui aggiungere?");
            foreach (Prodotto item in lista)
            {
                Console.WriteLine(i + ". " + item.Descrizione);
                i++;
            }
            try
            {
                int r = Convert.ToInt32(Console.ReadLine());
                Prodotto p = lista[r];
                RigaDettaglio rd = new RigaDettaglio(p, 1);
                utente.Carrello.Prodotti.Add(p, rd);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        private static void Rimuovi(List<Prodotto> lista, Utente utente)
        {
            int i = 0;
            Console.WriteLine("Quale prodotto vuoi eliminare?");
            foreach (Prodotto item in utente.Carrello.Prodotti.Keys)
            {
                Console.WriteLine(item.Codice + " - " + item.Descrizione);
            }
            string s2 = Console.ReadLine();
            Prodotto p = null;
            foreach (Prodotto item in lista)
            {
                if (s2 == item.Codice)
                {
                    p = item;
                }

            }
            try
            {
                utente.Carrello.Prodotti.Remove(p);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void ModificaCarrello(List<Prodotto> lista, Utente utente)
        {
            int i = 0;
            Console.WriteLine("Quale quantita vuoi modificare?");
            foreach (Prodotto item in utente.Carrello.Prodotti.Keys)
            {
                Console.WriteLine(item.Codice + ". " + item.Descrizione);
            }
            try
            {
                string s2 = Console.ReadLine();
                Prodotto p = null;
                foreach (Prodotto item in lista)
                {
                    if (s2 == item.Codice)
                    {
                        p = item;
                    }

                }

                RigaDettaglio rd = utente.Carrello.Prodotti[p];
                Console.WriteLine("inserisci nuova quantità");
                int r = Convert.ToInt32(Console.ReadLine());
                rd.Quantita = r;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void VisualizzaCarrello(Utente utente)
        {
            foreach (Prodotto item in utente.Carrello.Prodotti.Keys)
            {
                Console.WriteLine(item.Codice + " - " + item.Descrizione + " " + utente.Carrello.Prodotti[item].Quantita);
            }
        }
    }
}


