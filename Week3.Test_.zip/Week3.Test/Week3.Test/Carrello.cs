﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3.Test
{
    class Carrello
    {
        public Dictionary<Prodotto, RigaDettaglio> Prodotti { get; set; } = new Dictionary<Prodotto, RigaDettaglio>();
        public double PrezzoFinale { get  {return CalcoloPF();} }

        private double CalcoloPF()
        {
            double temp = 0.0;
            foreach (var item in Prodotti.Values)
            {
                temp = temp + item.PrezzoTotaleScontato;
            }
            return temp;
        }


    }
}
