﻿namespace Week3.Test
{
    class RigaDettaglio
    {
        public Prodotto Prodotto { get; set; }
        public int Quantita { get; set; }
        public double PrezzoTotale { get { return CalcoloPT(); } }
        public double PrezzoTotaleScontato { get { return CalcoloPTS(); } }

        public RigaDettaglio(Prodotto p, int q)
        {
            Prodotto = p;
            Quantita = q;
        }

        private double CalcoloPT()
        {
            double temp = Prodotto.Prezzo * Quantita;
            return temp;
        }
        private double CalcoloPTS()
        {
            double sconto = (Prodotto.Prezzo) * (Prodotto.Sconto / 100.00);
            double temp2 = (Prodotto.Prezzo) - sconto;

            double temp = temp2 * Quantita;
            return temp;
        }

    }
}