﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3.Test
{
    class Utente
    {
        public string Username { get; set; }
        public string Password { get; set;}
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public Carrello Carrello { get; set; } = new Carrello();

        public Utente(string u, string p, string n, string c)
        {
            Username = u;
            Password = p;
            Nome = n;
            Cognome = c;
        }
    }
}
