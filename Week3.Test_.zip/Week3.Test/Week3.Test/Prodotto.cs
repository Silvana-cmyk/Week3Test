﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3.Test
{
    public abstract class Prodotto
    {
        public string Codice { get; set; }
        public string Descrizione { get; set; }
        public double Prezzo { get; set; }
        public int Sconto { get; set; } //se è 20 allora ho il 20% di sconto

        public Prodotto(string c, string d, double p, int s)
        {
            Codice = c;
            Descrizione = d;
            Prezzo = p;
            Sconto = s;
        }
    }
}
